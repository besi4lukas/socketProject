#This is the ReadMe File for this project, subject to editing and revision for latter versions of the program

You can run the program in the command line by:
	Server:- python server.py <port number> 
	Client:- python client.py <ip address> <port number>
	